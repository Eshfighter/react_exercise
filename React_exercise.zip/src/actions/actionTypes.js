const GET_CRYPTO_INFO = 'GET_CRYPTO_INFO';

export default { GET_CRYPTO_INFO };
