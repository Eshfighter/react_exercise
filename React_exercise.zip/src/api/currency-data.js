const currencies = [ "SGD","AUD","EUR","GBP","USD","VND"]

export default currencies;