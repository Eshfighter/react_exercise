// import React from 'react';
// import expect from 'expect';
// import { mount, shallow } from 'enzyme';
// import HomePage from '../HomePage';

// const initializeComponent = (props) => shallow(<HomePage {...props} />);

// it(`Home component renders`, () => {
//   const component = initializeComponent();
//   expect(component.find('h1').length).toBe(1);
//   expect(component.find('h1').text()).toEqual('Top 5 Cryptocurrency Summary');
// });